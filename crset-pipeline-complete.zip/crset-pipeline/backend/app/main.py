"""
CRSET Solutions - Backend API
FastAPI application with Stripe, Supabase, OpenAI integrations
"""

from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel
import os
import stripe
import openai
from supabase import create_client, Client
import logging
from typing import Optional, Dict, Any

# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Inicializar FastAPI
app = FastAPI(
    title="CRSET Solutions API",
    description="Backend API para CRSET Solutions com integrações Stripe, Supabase e OpenAI",
    version="1.0.0"
)

# Configurar CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Em produção, especificar domínios
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configurar integrações
stripe.api_key = os.getenv("STRIPE_SECRET_KEY")
openai.api_key = os.getenv("OPENAI_API_KEY")

# Supabase
supabase_url = os.getenv("SUPABASE_URL")
supabase_key = os.getenv("SUPABASE_ANON_KEY")
supabase: Client = create_client(supabase_url, supabase_key)

# Security
security = HTTPBearer()

# Models
class HealthResponse(BaseModel):
    status: str
    message: str
    version: str

class LeadData(BaseModel):
    name: str
    email: str
    company: Optional[str] = None
    message: str

class PaymentIntent(BaseModel):
    amount: int
    currency: str = "eur"
    description: Optional[str] = None

class AIQuery(BaseModel):
    message: str
    context: Optional[str] = None

# Routes
@app.get("/", response_model=HealthResponse)
async def root():
    """Root endpoint"""
    return HealthResponse(
        status="success",
        message="CRSET Solutions API is running",
        version="1.0.0"
    )

@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint para Railway"""
    return HealthResponse(
        status="healthy",
        message="All systems operational",
        version="1.0.0"
    )

@app.post("/api/leads")
async def create_lead(lead: LeadData):
    """Criar nova lead no Supabase"""
    try:
        # Inserir lead na base de dados
        result = supabase.table("leads").insert({
            "name": lead.name,
            "email": lead.email,
            "company": lead.company,
            "message": lead.message,
            "created_at": "now()"
        }).execute()
        
        logger.info(f"Nova lead criada: {lead.email}")
        
        # TODO: Integrar com WhatsApp/Email notifications
        
        return {"status": "success", "lead_id": result.data[0]["id"]}
    
    except Exception as e:
        logger.error(f"Erro ao criar lead: {str(e)}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@app.post("/api/payments/create-intent")
async def create_payment_intent(payment: PaymentIntent):
    """Criar Payment Intent do Stripe"""
    try:
        intent = stripe.PaymentIntent.create(
            amount=payment.amount,
            currency=payment.currency,
            description=payment.description,
            automatic_payment_methods={"enabled": True}
        )
        
        return {"client_secret": intent.client_secret}
    
    except stripe.error.StripeError as e:
        logger.error(f"Erro Stripe: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/ai/chat")
async def ai_chat(query: AIQuery):
    """Chat com OpenAI"""
    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "És o assistente IA da CRSET Solutions. Responde de forma profissional e útil."},
                {"role": "user", "content": query.message}
            ],
            max_tokens=500
        )
        
        return {"response": response.choices[0].message.content}
    
    except Exception as e:
        logger.error(f"Erro OpenAI: {str(e)}")
        raise HTTPException(status_code=500, detail="Erro no serviço de IA")

@app.post("/api/webhooks/stripe")
async def stripe_webhook(request: Dict[Any, Any]):
    """Webhook do Stripe para eventos de pagamento"""
    try:
        # TODO: Verificar assinatura do webhook
        # TODO: Processar eventos de pagamento
        
        event_type = request.get("type")
        logger.info(f"Webhook Stripe recebido: {event_type}")
        
        return {"status": "success"}
    
    except Exception as e:
        logger.error(f"Erro webhook Stripe: {str(e)}")
        raise HTTPException(status_code=500, detail="Erro no webhook")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

